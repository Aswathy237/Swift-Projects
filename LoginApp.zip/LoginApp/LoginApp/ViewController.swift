//
//  ViewController.swift
//  LoginApp
//
//  Created by 61086256 on 16/09/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var UIScrollView: UIScrollView!
    @IBOutlet weak var UIStackView: UIStackView!
    
    private let pickerView = UIPickerView()
    private var experienceTypeField: UITextField?
    
    var viewModel = FieldsViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //UIScrollView.backgroundColor = UIColor.lightGray
        //setupScrollView()
        setupStackView()
        setupConstraints()
        setupViewModel()
        
        viewModel.fetchFields()
        pickerView.delegate = self
        pickerView.dataSource = self
        
    }
    private func setupScrollView() {
        UIScrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(UIScrollView)
    }
    private func setupStackView() {
        UIStackView.translatesAutoresizingMaskIntoConstraints = false
        UIStackView.axis = .vertical
        UIStackView.distribution = .fill
        UIStackView.spacing = 8
        UIScrollView.addSubview(UIStackView)
    }
    private func setupConstraints() {  
        // ScrollView Constraints
        NSLayoutConstraint.activate([ UIScrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor), UIScrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor), UIScrollView.topAnchor.constraint(equalTo: view.topAnchor), UIScrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor) ])
        // StackView Constraints inside ScrollView
        NSLayoutConstraint.activate([ UIStackView.leadingAnchor.constraint(equalTo: UIScrollView.leadingAnchor), UIStackView.trailingAnchor.constraint(equalTo: UIScrollView.trailingAnchor), UIStackView.topAnchor.constraint(equalTo: UIScrollView.topAnchor), UIStackView.bottomAnchor.constraint(equalTo: UIScrollView.bottomAnchor), UIStackView.widthAnchor.constraint(equalTo: UIScrollView.widthAnchor) ])
    }
            // Set constraints for stackView
//            NSLayoutConstraint.activate([
//                UIStackView.leadingAnchor.constraint(equalTo: UIScrollView.leadingAnchor),
//                UIStackView.trailingAnchor.constraint(equalTo: UIScrollView.trailingAnchor),
//                UIStackView.topAnchor.constraint(equalTo: UIScrollView.topAnchor),
//                UIStackView.bottomAnchor.constraint(equalTo: UIScrollView.bottomAnchor),
//                UIStackView.widthAnchor.constraint(equalTo: UIScrollView.widthAnchor)
//            ])
//        
    private func setupViewModel() {
            viewModel.onFieldsUpdated = { [weak self] in
                print("Fields updated-creating dynamic fields.")
                self?.createDynamicFields()
            }
        }
    private func createDynamicFields() {
        let fields = viewModel.getFields()
        print("Number of fields: \(fields.count)")
        guard !fields.isEmpty else {
            print("No fields to create")
            return
        }
        
        for field in fields {
            let label = UILabel()
            label.text = field.label
            label.translatesAutoresizingMaskIntoConstraints = false
            print("creating fields: \(field.label)")
            
            switch field.dataTypeId {
            case 1: // INPUT_TEXT
                let textField = UITextField()
                textField.borderStyle = .roundedRect
                textField.translatesAutoresizingMaskIntoConstraints = false
                UIStackView.addArrangedSubview(label)
                UIStackView.addArrangedSubview(textField)
            case 2: // PASSWORD
                let passwordField = UITextField()
                passwordField.borderStyle = .roundedRect
                passwordField.isSecureTextEntry = true
                passwordField.translatesAutoresizingMaskIntoConstraints = false
                UIStackView.addArrangedSubview(label)
                UIStackView.addArrangedSubview(passwordField)
            case 3: // DROPDOWN
                
                let dropdown = UIPickerView() // Customize this as needed
                dropdown.translatesAutoresizingMaskIntoConstraints = false
                UIStackView.addArrangedSubview(label)
                UIStackView.addArrangedSubview(dropdown)
                
            case 4: // DATE CONTROL
                let datePicker = UIDatePicker()
                datePicker.datePickerMode = .date
                datePicker.translatesAutoresizingMaskIntoConstraints = false
                UIStackView.addArrangedSubview(label)
                UIStackView.addArrangedSubview(datePicker)
            case 5: // MULTIPLE_ATTACHMENT
                 let attachmentsView = UIButton(type: .system)
                attachmentsView.translatesAutoresizingMaskIntoConstraints = false
                attachmentsView.setTitle("Passport Size Photo(with white background)", for: .normal)
                UIStackView.addArrangedSubview(attachmentsView)
                
            default:
                break
            }
        }
    }
    
    func createPickerView(for field: Field) -> UIView {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.tag = field.sequence
        // Use field's sequence as tag to identify it later 
        return pickerView
    }
}
extension ViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        let field = viewModel.fields.first {
            $0.sequence == pickerView.tag
        } 
        return field?.suggestedValues?.count ?? 0
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let field = viewModel.fields.first
        {
            $0.sequence == pickerView.tag
        } 
        return field?.suggestedValues?[row].title
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let field = viewModel.fields.first
        {
            $0.sequence == pickerView.tag
        }
        let selectedTitle = field?.suggestedValues?[row].title 
        print("Selected: \(selectedTitle ?? "")")
    }
}

    


