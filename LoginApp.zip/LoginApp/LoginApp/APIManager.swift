//
//  APIManager.swift
//  LoginApp
//
//  Created by 61086256 on 18/09/24.
//

import Foundation

class APIManager {

    static let shared = APIManager()

        func getFields(completion: @escaping (Result<FieldResponse, Error>) -> Void) {
            let url = URL(string: "http://dev.fileshore.com/api/document/getFsFormDataDemo")!
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            //
            // Configure headers and body here if needed
            
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                if let data = data {
                    do {
                        let fieldResponse = try JSONDecoder().decode(FieldResponse.self, from: data)
                        completion(.success(fieldResponse))
                    } catch {
                        completion(.failure(error))
                    }
                } else if let error = error {
                    completion(.failure(error))
                }
            }
            task.resume()
        }

}
