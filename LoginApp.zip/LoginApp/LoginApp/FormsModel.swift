//
//  FormsModel.swift
//  LoginApp
//
//  Created by 61086256 on 16/09/24.
//

import Foundation

struct FieldResponse: Codable {
    let status: Bool
    let message: String
    let data: FieldData
}

struct FieldData: Codable {
    let list: [Field]
}

struct Field: Codable {
    let fieldID: String
    let dataTypeId: Int
    let sequence: Int
    let label: String
    let suggestedValues: [SuggestedValue]?
}

struct SuggestedValue: Codable {
    let id: Int
    let title: String
}
