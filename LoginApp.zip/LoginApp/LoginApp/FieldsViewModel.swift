//
//  FieldsViewModel.swift
//  LoginApp
//
//  Created by 61086256 on 16/09/24.
//

import Foundation

class FieldsViewModel {
   // var fields: [Field] = []
    var experienceTypeOptions: [String] = []
    
    // Closure-based binding to notify the view when the data is updated
    var onFieldsUpdated: (() -> Void)?
    
    var fields: [Field] = [] {
            didSet {
                onFieldsUpdated?()
            }
        }
    
    func fetchFields() {
        APIManager.shared.getFields { [weak self] result in
               switch result {
               case .success(let fieldResponse):
                   DispatchQueue.main.async {
                       self?.fields = fieldResponse.data.list
                   }
               case .failure(let error):
                   print("Failed to fetch fields: \(error)")
               }
           }
        for field in fields {
            if field.dataTypeId == 3, let options = field.suggestedValues {
                experienceTypeOptions = options.map {$0.title}
            }
        }
        
        }
    
    // Fetch data from the API
    //func fetchFields() {
        //print("fetching fields..")
        //        guard let url = URL(string: "http://dev.fileshore.com/api/document/getFsFormDataDemo") else { return }
        //        var request = URLRequest(url: url)
        //        request.httpMethod = "POST"
        //        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        //        request.addValue("application/json", forHTTPHeaderField: "Accept")
        //
        
        //        let task = URLSession.shared.dataTask(with: request) { data, response, error in
        //
        //            if let data = data {
        //
        //                do {
        //
        //                    // Try decoding the response into the FieldResponse model
        //
        //                    let response = try JSONDecoder().decode(FieldResponse.self, from: data)
        //
        //                    print("Decoded response: \(response)")
        //                    response.shared.getFields() {result in
        //                        switch result {
        //                        case .success (let fieldResponse):
        //                            self.fields = FieldResponse.data.list
        //                        case .failure(let error):
        //                            print("failed to fetch fields \(error)")
        //                        }
        //                    }
        //                    DispatchQueue.main.async {
        //
        //                        // Update your fields here
        //
        //                        self.fields = response.data.list
        //
        //                        self.onFieldsUpdated?()
        //
        ////                    }
        //
        //                } catch let DecodingError.dataCorrupted(context) {
        //
        //                    print("Data corrupted: \(context.debugDescription)")
        //
        //                } catch let DecodingError.keyNotFound(key, context) {
        //
        //                    print("Key '\(key)' not found: \(context.debugDescription)")
        //
        //                } catch let DecodingError.typeMismatch(type, context) {
        //
        //                    print("Type mismatch for type \(type): \(context.debugDescription)")
        //
        //                } catch let DecodingError.valueNotFound(value, context) {
        //
        //                    print("Value not found for \(value): \(context.debugDescription)")
        //
        //                } catch {
        //
        //                    print("Unknown error: \(error.localizedDescription)")
        //
        //                }
        //
        //            } else if let error = error {
        //
        //                print("Error: \(error)")
        //
        //            }
        //
        //        }
        //
        //        task.resume()
        
        // }
        
        
        
        
        //        let task = URLSession.shared.dataTask(with: request)
        //        { [weak self] data, response, error in
        //            guard let self = self else { return }
        //            if let data = data {
        //                let dataString = String(data: data, encoding: .utf8)
        //                print("Raw response: \(String(describing: dataString))")
        //                do {
        //                    let response = try JSONDecoder().decode(FieldResponse.self, from: data)
        //                    self.fields = response.data.list
        //                    print("Data fetched: \(self.fields.count) fields")
        //                    DispatchQueue.main.async {
        //                        print("Updating UI")
        //                        self.onFieldsUpdated?()
        //                    }
        //                }
        //                catch
        //                {
        //                    print("Failed to decode JSON: \(error.localizedDescription)")
        //                }
        //            }
        //            else if let error = error { print("Error fetching data: \(error.localizedDescription)")
        //            }
        //        }
        //        task.resume()
        
        //        let requestBody: [String: Any] = [
        //            "key1": "value1",
        //            "key2": "value2"]
        //        do { // Convert the dictionary to JSON data
        //            request.httpBody = try JSONSerialization.data(withJSONObject: requestBody, options: []) } catch { print("Failed to serialize JSON: \(error.localizedDescription)") }
        //        // Create a URLSession data task
        //        let task = URLSession.shared.dataTask(with: request) { data, response, error in
        //            if let error = error { print("Error: \(error.localizedDescription)")
        //                return
        //            }
        //            guard let httpResponse = response as? HTTPURLResponse else { print("Invalid response")
        //                return
        //            } // Print the HTTP status code
        //            print("HTTP Status Code: \(httpResponse.statusCode)")
        //            // Print the raw data for debugging
        //            if let data = data, let responseString = String(data: data, encoding: .utf8) { print("Response Data: \(responseString)")
        //            }
        //        }
        //        // Start the task
        //        task.resume()
        
        
        
            func getFields() -> [Field] {
                return fields
            }
    //}
}
