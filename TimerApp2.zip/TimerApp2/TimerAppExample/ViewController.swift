//
//  ViewController.swift
//  TimerAppExample
//
//  Created by Aswathy on 6/9/24.
//

import UIKit
import DropDown

class ViewController: UIViewController
{
    @IBOutlet weak var TimerLabel: UILabel!
    @IBOutlet weak var startStopButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    
    var timer:Timer = Timer()
    var countInMilliseconds: Int = 0
    var timerCounting:Bool = false
    var isMilliSecondsMode: Bool = false
        
    var scheduledTimer: Timer!
    
    let dropDown = DropDown()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        startStopButton.setTitleColor(UIColor.systemPurple, for: .normal)
        resetButton.setTitleColor(UIColor.systemPurple, for: .normal)
        TimerLabel.text = makeTimeString(hours: 0, minutes: 0, seconds: 0)
        NotificationCenter.default.addObserver(self, selector: #selector(toggleStartPause), name: Notification.Name("ToggleStartPauseNotification"), object: nil)
                NotificationCenter.default.addObserver(self, selector: #selector(resetStopwatch), name: Notification.Name("ResetStopwatchNotification"), object: nil)
        updateTimerLabel()
    }
    
    deinit {
           NotificationCenter.default.removeObserver(self)
       }
    
    @objc func toggleStartPause() {
            if timerCounting {
                stopTimer()
                startStopButton.setTitle("START", for: .normal)
                startStopButton.setTitleColor(UIColor.systemPurple, for: .normal)
            } else {
                startTimer()
                startStopButton.setTitle("PAUSE", for: .normal)
                startStopButton.setTitleColor(UIColor.purple, for: .normal)
            }
            timerCounting.toggle()
        }
    @objc func resetStopwatch() {
            countInMilliseconds = 0
            stopTimer()
            updateTimerLabel()
            startStopButton.setTitle("START", for: .normal)
            startStopButton.setTitleColor(UIColor.systemPurple, for: .normal)
            timerCounting = false
        }

    @IBAction func chooseSecondsOrMilliSecondsButton(_ sender: Any) {
        guard let button = sender as? UIButton else {return}
        
        dropDown.dataSource = ["Seconds", "MilliSeconds"]
        dropDown.anchorView = button
        dropDown.bottomOffset = CGPoint(x: 0, y: (sender as AnyObject).frame.size.height)
        dropDown.show()
        
        dropDown.selectionAction = { [weak self] (index: Int, item: String) in
            guard let _ = self else { return }
            
            let wasTimerCounting = self?.timerCounting
            self?.stopTimer()
            
            //let wasMillisecondsMode = self?.isMilliSecondsMode
            self?.isMilliSecondsMode = (item == "MilliSeconds")
            
            button.setTitle(item, for: .normal)
            
//            self?.timer.invalidate()
            //self?.stopTimer()
            self?.updateTimerLabel()
            // if ((self?.timerCounting) != nil)
            
            if wasTimerCounting == true {
                self?.startTimer()
            }

            
        }
    }
    
    @IBAction func resetTapped(_ sender: Any)
    {
        self.countInMilliseconds = 0
        stopTimer()
        updateTimerLabel()
        self.startStopButton.setTitle("START", for: .normal)
        self.startStopButton.setTitleColor(UIColor.systemPurple, for: .normal)
        self.timerCounting = false
    }
    
    @IBAction func startStopTapped(_ sender: Any)
    {
        if(timerCounting)
        {
//            timerCounting = false
            stopTimer()
            startStopButton.setTitle("START", for: .normal)
            startStopButton.setTitleColor(UIColor.systemPurple, for: .normal)
        }
        else
        {
            //timerCounting = true
            startTimer()
            startStopButton.setTitle("PAUSE", for: .normal)
            startStopButton.setTitleColor(UIColor.purple, for: .normal)
        }
        timerCounting.toggle()
    }
    
    @objc func timerCounter() -> Void
    {
        countInMilliseconds += isMilliSecondsMode ? 10 : 1000
        updateTimerLabel()
    }
    
    func updateTimerLabel() { 
        if isMilliSecondsMode {
            let time = secondsToHoursMinutesSecondsMilliSeconds(milliseconds: countInMilliseconds)
            TimerLabel.text = makeTimeStringWithMilliSeconds(hours: time.0, minutes: time.1, seconds: time.2, milliseconds: time.3)
        } else {
            let totalSeconds = countInMilliseconds / 1000
            let time = secondsToHoursMinutesSeconds(seconds: totalSeconds)
            TimerLabel.text = makeTimeString(hours: time.0, minutes: time.1, seconds: time.2)
        }
    }
    
	func secondsToHoursMinutesSeconds(seconds: Int) -> (Int, Int, Int)
	{
		return ((seconds / 3600), ((seconds % 3600) / 60),((seconds % 3600) % 60))
	}
    
    func secondsToHoursMinutesSecondsMilliSeconds(milliseconds: Int) -> (Int, Int, Int, Int)
    {
        let totalSeconds = milliseconds/100
        let milliSecondsRemainder = milliseconds % 100
        return (totalSeconds / 3600, (totalSeconds % 3600) / 60, (totalSeconds % 3600) % 60, milliSecondsRemainder)
    }
	
	func makeTimeString(hours: Int, minutes: Int, seconds : Int) -> String
	{
		var timeString = ""
		timeString += String(format: "%02d", hours)
		timeString += " : "
		timeString += String(format: "%02d", minutes)
		timeString += " : "
		timeString += String(format: "%02d", seconds)
		return timeString
	}
    
    func makeTimeStringWithMilliSeconds(hours: Int, minutes: Int, seconds : Int, milliseconds: Int) -> String
    {
        var timeString = ""
        timeString += String(format: "%02d", hours)
        timeString += " : "
        timeString += String(format: "%02d", minutes)
        timeString += " : "
        timeString += String(format: "%02d", seconds)
        timeString += " : "
        timeString += String(format: "%02d", milliseconds)
        return timeString
    }
	
    func startTimer() {
        let interval = isMilliSecondsMode ? 0.01 : 1.0
        timer = Timer.scheduledTimer(timeInterval: interval, target: self, selector: #selector(timerCounter), userInfo: nil, repeats: true)
    }
    func stopTimer() {
       
        timer.invalidate()
    }
    
}

